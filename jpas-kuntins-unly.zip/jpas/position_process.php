<?php
require 'db_con.php';
//eto yung paraan para makapag delete ng position
// delete_position position_id positions yan pwede galawin yan
if(isset($_POST['delete_position'])){
    $position_id = mysqli_real_escape_string($con,$_POST['position_id']);
    $query = "DELETE FROM position WHERE id='$position_id'";
    $query_run = mysqli_query($con,$query);

    if($query_run){
        $res = [
            //statuses of input error
            'status' => 200,
            'message' => 'Position Info has been removed.'
        ];
        echo json_encode($res);
        return false;
    }else{
        $res = [
            //statuses of input error
            'status' => 500,
            'message' => 'Position Info not Deleted'
        ];
        echo json_encode($res);
        return false;
    }

}
//eto yung paraan para masave yung mga inedit na data mo sa input
// mga variable napwedeng palitan o dagdagan depende sa trip mo update_position position_id firstname, lastname, address, contact_info
if(isset($_POST['update_position'])){
    $position_id = mysqli_real_escape_string($con,$_POST['position_id']);
    //real escapre string function will protect you from sql function
    $description = mysqli_real_escape_string($con,$_POST['description']);
    $rate = mysqli_real_escape_string($con,$_POST['rate']);
    
    if($description==NULL||$rate==NULL){
        
        $res = [
            //statuses of input error
            'status' => 422,
            'message' => 'All fields are Mandatory'
        ];
        echo json_encode($res);
        return false;

        
    }
   //firstname lastname address contact_info position_id positions can change
    $query = "UPDATE position SET description='$description', rate='$rate' WHERE id='$position_id'";
    $query_run = mysqli_query($con,$query);

    if($query_run){
        $res = [
            //statuses of input error
            'status' => 200,
            'message' => 'Position Info is Update Successfully'
        ];
        echo json_encode($res);
        return false;
    }else{
        $res = [
            //statuses of input error
            'status' => 500,
            'message' => 'Position did not Updated'
        ];
        echo json_encode($res);
        return false;
    }
}
//fetch position to text box of update can change
//position_id positions position
if(isset($_GET['position_id'])){
    $position_id = mysqli_real_escape_string($con,$_GET['position_id']);
    $query = "SELECT * FROM position WHERE id='$position_id'";
    $query_run = mysqli_query($con,$query);
    if(mysqli_num_rows($query_run)== 1){
        $position =mysqli_fetch_array($query_run);
        $res = [
            //statuses of input error
            'status' => 200,
            'message' => 'Position fetch successfully by id',
            'data' => $position
        ];
        echo json_encode($res);
        return false;
    }
    else{
        $res = [
            //statuses of input error
            'status' => 404,
            'message' => 'What?'
        ];
        echo json_encode($res);
        return false;
    }
}
//add position
////firstname lastname address contact_info 
if(isset($_POST['save_position'])){

    //real escapre string function will protect you from sql injectio function
    $description = mysqli_real_escape_string($con,$_POST['description']);
    $rate = mysqli_real_escape_string($con,$_POST['rate']);

    if($description==NULL||$rate==NULL){
        $res = [
            //statuses of input error
            'status' => 422,
            'message' => 'All fields are Mandatory'
        ];
        echo json_encode($res);
        return false;
    }
    //firstname lastname address contact_info created_on
    $query = "INSERT INTO position (description,rate) VALUES ('$description','$rate')";
    $query_run = mysqli_query($con,$query);

    if($query_run){
        $res = [
            //statuses of input error
            'status' => 200,
            'message' => 'New Position is Recorded.'
        ];
        echo json_encode($res);
        return false;
    }else{
        $res = [
            //statuses of input error
            'status' => 500,
            'message' => 'Postion did not created :('
        ];
        echo json_encode($res);
        return false;
    }
}
?>