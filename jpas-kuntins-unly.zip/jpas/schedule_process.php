<?php
require 'db_con.php';
//eto yung paraan para makapag delete ng schedule
// delete_schedule schedule_id positions yan pwede galawin yan
if(isset($_POST['delete_schedule'])){
    $schedule_id = mysqli_real_escape_string($con,$_POST['schedule_id']);
    $query = "DELETE FROM schedules WHERE id='$schedule_id'";
    $query_run = mysqli_query($con,$query);

    if($query_run){
        $res = [
            //statuses of input error
            'status' => 200,
            'message' => 'Shift Info has been removed.'
        ];
        echo json_encode($res);
        return false;
    }else{
        $res = [
            //statuses of input error
            'status' => 500,
            'message' => 'Shift Info not Deleted'
        ];
        echo json_encode($res);
        return false;
    }

}
//eto yung paraan para masave yung mga inedit na data mo sa input
// mga variable napwedeng palitan o dagdagan depende sa trip mo update_schedule schedule_id firstname, lastname, address, contact_info
if(isset($_POST['update_schedule'])){
    $schedule_id = mysqli_real_escape_string($con,$_POST['schedule_id']);
    //real escapre string function will protect you from sql function
    $time_in = mysqli_real_escape_string($con,$_POST['time_in']);
    $time_out = mysqli_real_escape_string($con,$_POST['time_out']);
    
    if($time_in==NULL||$time_out==NULL){
        
        $res = [
            //statuses of input error
            'status' => 422,
            'message' => 'All fields are Mandatory'
        ];
        echo json_encode($res);
        return false;

        
    }
   //firstname lastname address contact_info schedule_id positions can change
    $query = "UPDATE schedules SET time_in='$time_in', time_out='$time_out' WHERE id='$schedule_id'";
    $query_run = mysqli_query($con,$query);

    if($query_run){
        $res = [
            //statuses of input error
            'status' => 200,
            'message' => 'Shfit Info is Update Successfully'
        ];
        echo json_encode($res);
        return false;
    }else{
        $res = [
            //statuses of input error
            'status' => 500,
            'message' => 'Shift info did not Updated'
        ];
        echo json_encode($res);
        return false;
    }
}
//fetch schedule to text box of update can change
//schedule_id positions schedule
if(isset($_GET['schedule_id'])){
    $schedule_id = mysqli_real_escape_string($con,$_GET['schedule_id']);
    $query = "SELECT * FROM schedules WHERE id='$schedule_id'";
    $query_run = mysqli_query($con,$query);
    if(mysqli_num_rows($query_run)== 1){
        $schedule =mysqli_fetch_array($query_run);
        $res = [
            //statuses of input error
            'status' => 200,
            'message' => 'Shift fetch successfully by id',
            'data' => $schedule
        ];
        echo json_encode($res);
        return false;
    }
    else{
        $res = [
            //statuses of input error
            'status' => 404,
            'message' => 'What?'
        ];
        echo json_encode($res);
        return false;
    }
}
//add schedule
////firstname lastname address contact_info 
if(isset($_POST['save_schedule'])){

    //real escapre string function will protect you from sql injectio function
    $time_in = mysqli_real_escape_string($con,$_POST['time_in']);
    $time_out = mysqli_real_escape_string($con,$_POST['time_out']);

    if($time_in==NULL||$time_out==NULL){
        $res = [
            //statuses of input error
            'status' => 422,
            'message' => 'All fields are Mandatory'
        ];
        echo json_encode($res);
        return false;
    }
    //firstname lastname address contact_info created_on
    $query = "INSERT INTO schedules (time_in,time_out) VALUES ('$time_in','$time_out')";
    $query_run = mysqli_query($con,$query);

    if($query_run){
        $res = [
            //statuses of input error
            'status' => 200,
            'message' => 'New Shift is Recorded.'
        ];
        echo json_encode($res);
        return false;
    }else{
        $res = [
            //statuses of input error
            'status' => 500,
            'message' => 'Postion did not created :('
        ];
        echo json_encode($res);
        return false;
    }
}
?>