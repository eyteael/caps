<?php
require 'db_con.php';
//eto yung paraan para makapag delete ng employee
// delete_employee employee_id employees yan pwede galawin yan
if(isset($_POST['delete_employee'])){
    $employee_id = mysqli_real_escape_string($con,$_POST['employee_id']);
    $query = "DELETE FROM employees WHERE id='$employee_id'";
    $query_run = mysqli_query($con,$query);

    if($query_run){
        $res = [
            //statuses of input error
            'status' => 200,
            'message' => 'Employee data has been removed.'
        ];
        echo json_encode($res);
        return false;
    }else{
        $res = [
            //statuses of input error
            'status' => 500,
            'message' => 'Not deleted'
        ];
        echo json_encode($res);
        return false;
    }

}
//eto yung paraan para masave yung mga inedit na data mo sa input
// mga variable napwedeng palitan o dagdagan depende sa trip mo update_employee employee_id firstname, lastname, address, contact_info
if(isset($_POST['update_employee'])){
    $employee_id = mysqli_real_escape_string($con,$_POST['employee_id']);
    //real escapre string function will protect you from sql function
    $firstname = mysqli_real_escape_string($con,$_POST['firstname']);
    $lastname = mysqli_real_escape_string($con,$_POST['lastname']);
    $address = mysqli_real_escape_string($con,$_POST['address']);
    $contact_info = mysqli_real_escape_string($con,$_POST['contact_info']);
    
    if($firstname==NULL||$lastname==NULL||$address==NULL||$contact_info==NULL){
        
        $res = [
            //statuses of input error
            'status' => 422,
            'message' => 'All field are madatory'
        ];
        echo json_encode($res);
        return false;

        
    }
   //firstname lastname address contact_info employee_id employees can change
    $query = "UPDATE employees SET firstname='$firstname', lastname='$lastname', address='$address', contact_info='$contact_info' WHERE id='$employee_id'";
    $query_run = mysqli_query($con,$query);

    if($query_run){
        $res = [
            //statuses of input error
            'status' => 200,
            'message' => 'Student Update Successfully'
        ];
        echo json_encode($res);
        return false;
    }else{
        $res = [
            //statuses of input error
            'status' => 500,
            'message' => 'Student not Updated'
        ];
        echo json_encode($res);
        return false;
    }
}
//fetch employee to text box of update can change
//employee_id employees employee
if(isset($_GET['employee_id'])){
    $employee_id = mysqli_real_escape_string($con,$_GET['employee_id']);
    $query = "SELECT * FROM employees WHERE id='$employee_id'";
    $query_run = mysqli_query($con,$query);
    if(mysqli_num_rows($query_run)== 1){
        $employee =mysqli_fetch_array($query_run);
        $res = [
            //statuses of input error
            'status' => 200,
            'message' => 'Employee fetch successfully by id',
            'data' => $employee
        ];
        echo json_encode($res);
        return false;
    }
    else{
        $res = [
            //statuses of input error
            'status' => 404,
            'message' => 'Student id not found'
        ];
        echo json_encode($res);
        return false;
    }
}
//add employee
////firstname lastname address contact_info 
if(isset($_POST['save_employee'])){

    //real escapre string function will protect you from sql injectio function
    $firstname = mysqli_real_escape_string($con,$_POST['firstname']);
    $lastname = mysqli_real_escape_string($con,$_POST['lastname']);
    $address = mysqli_real_escape_string($con,$_POST['address']);
    $contact_info = mysqli_real_escape_string($con,$_POST['contact_info']);

    if($firstname==NULL||$lastname==NULL||$address==NULL||$contact_info==NULL){
        $res = [
            //statuses of input error
            'status' => 422,
            'message' => 'All field are madatory'
        ];
        echo json_encode($res);
        return false;
    }
    //firstname lastname address contact_info created_on
    $query = "INSERT INTO employees (firstname,lastname,address,contact_info,created_on) VALUES ('$firstname','$lastname','$address','$contact_info',NOW())";
    $query_run = mysqli_query($con,$query);

    if($query_run){
        $res = [
            //statuses of input error
            'status' => 200,
            'message' => 'New employee recorded.'
        ];
        echo json_encode($res);
        return false;
    }else{
        $res = [
            //statuses of input error
            'status' => 500,
            'message' => 'Employee not created'
        ];
        echo json_encode($res);
        return false;
    }
}
?>