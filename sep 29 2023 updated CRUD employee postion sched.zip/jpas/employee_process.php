<?php
require 'db_con.php';
//eto yung paraan para makapag delete ng employee
// delete_employee employee_id employees yan pwede galawin yan
if(isset($_POST['delete_employee'])){
    $employee_id = mysqli_real_escape_string($con,$_POST['employee_id']);
    $query = "DELETE FROM employees WHERE id='$employee_id'";
    $query_run = mysqli_query($con,$query);

    if($query_run){
        $res = [
            //statuses of input error
            'status' => 200,
            'message' => 'Employee data has been removed.'
        ];
        echo json_encode($res);
        return false;
    }else{
        $res = [
            //statuses of input error
            'status' => 500,
            'message' => 'Not deleted :('
        ];
        echo json_encode($res);
        return false;
    }

}
//eto yung paraan para masave yung mga inedit na data mo sa input
// mga variable napwedeng palitan o dagdagan depende sa trip mo update_employee employee_id firstname, lastname, address, contact_info
if(isset($_POST['update_employee'])){
    $employee_id = mysqli_real_escape_string($con,$_POST['employee_id']);
    //real escapre string function will protect you from sql function
    $firstname = mysqli_real_escape_string($con,$_POST['firstname']);
    $lastname = mysqli_real_escape_string($con,$_POST['lastname']);
    $address = mysqli_real_escape_string($con,$_POST['address']);
    $birthdate = mysqli_real_escape_string($con,$_POST['birthdate']);
    $contact_info = mysqli_real_escape_string($con,$_POST['contact_info']);
    $gender = mysqli_real_escape_string($con,$_POST['gender']);
    $position = mysqli_real_escape_string($con,$_POST['position']);
    $schedule = mysqli_real_escape_string($con,$_POST['schedule']);
    
    if($firstname==NULL||$lastname==NULL||$address==NULL||$contact_info==NULL){
        
        $res = [
            //statuses of input error
            'status' => 422,
            'message' => 'All fields are madatory'
        ];
        echo json_encode($res);
        return false;

        
    }
   //firstname lastname address contact_info employee_id employees can change
    $query = "UPDATE employees SET firstname='$firstname', lastname='$lastname', address='$address', birthdate='$birthdate', contact_info='$contact_info', gender='$gender', position_id='$position', schedule_id='$schedule' WHERE id='$employee_id'";
    $query_run = mysqli_query($con,$query);

    if($query_run){
        $res = [
            //statuses of input error
            'status' => 200,
            'message' => 'Employee Info is Update Successfully'
        ];
        echo json_encode($res);
        return false;
    }else{
        $res = [
            //statuses of input error
            'status' => 500,
            'message' => 'Employee not Updated :('
        ];
        echo json_encode($res);
        return false;
    }
}
//fetch employee to text box of update can change
//employee_id employees employee
if(isset($_GET['employee_id'])){
    $employee_id = mysqli_real_escape_string($con,$_GET['employee_id']);
    $query = "SELECT * FROM employees WHERE id='$employee_id'";
    $query_run = mysqli_query($con,$query);
    if(mysqli_num_rows($query_run)== 1){
        $employee =mysqli_fetch_array($query_run);
        $res = [
            //statuses of input error
            'status' => 200,
            'message' => 'Employee fetch successfully by id',
            'data' => $employee
        ];
        echo json_encode($res);
        return false;
    }
    else{
        $res = [
            //statuses of input error
            'status' => 404,
            'message' => 'Employee did not found :('
        ];
        echo json_encode($res);
        return false;
    }
}
//add employee
////firstname lastname address contact_info 
if(isset($_POST['save_employee'])){
//sa name nakabatay ang mga putang inang yan
    //real escapre string function will protect you from sql injectio function
    $firstname = mysqli_real_escape_string($con,$_POST['firstname']);
    $lastname = mysqli_real_escape_string($con,$_POST['lastname']);
    $address = mysqli_real_escape_string($con,$_POST['address']);
    $birthdate = mysqli_real_escape_string($con,$_POST['birthdate']);
    $contact_info = mysqli_real_escape_string($con,$_POST['contact_info']);
    $gender = mysqli_real_escape_string($con,$_POST['gender']);
    $position = mysqli_real_escape_string($con,$_POST['position']);
    $schedule = mysqli_real_escape_string($con,$_POST['schedule']);
    
    //creating employeeid
		$letters = '';
		$numbers = '';
		foreach (range('A', 'Z') as $char) {
		    $letters .= $char;
		}
		for($i = 0; $i < 10; $i++){
			$numbers .= $i;
		}
		$employee_id = substr(str_shuffle($letters), 0, 3).substr(str_shuffle($numbers), 0, 9);

    if($firstname==NULL||$lastname==NULL||$address==NULL||$birthdate==NULL||$contact_info==NULL||$gender==NULL||$position==NULL||$schedule==NULL){
        $res = [
            //statuses of input error
            'status' => 422,
            'message' => 'All field are madatory'
        ];
        echo json_encode($res);
        return false;
    }
    //firstname lastname address contact_info created_on
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      
    $query = "INSERT INTO employees (employee_id, firstname, lastname, address, birthdate, contact_info, gender, position_id, schedule_id, created_on) VALUES ('$employee_id', '$firstname', '$lastname', '$address', '$birthdate', '$contact_info', '$gender', '$position', '$schedule', NOW())";
    $query_run = mysqli_query($con,$query);

    if($query_run){
        $res = [
            //statuses of input error
            'status' => 200,
            'message' => 'New Employee Hired Succesfully. Congrats :)'
        ];
        echo json_encode($res);
        return false;
    }else{
        $res = [
            //statuses of input error
            'status' => 500,
            'message' => 'Employee not created :('
        ];
        echo json_encode($res);
        return false;
    }
}
?>