<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>JPAS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="lib\tpicker.css">
</head>
  <body>
<!-- tuss -->
<!-- toast - paramatawag yung toast      textMessage - para maapalitan yung laman -->
  <div class="toast-container position-fixed bottom-0 end-0 p-3">
  <div id="liveToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
    <div class="toast-header">
      <img src="..." class="rounded me-2" alt="...">
      <strong class="me-auto">JPAS</strong>
      <small>1 sec ago</small>
      <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
    <div class="toast-body" id="textMessage">

    </div>
  </div>
</div>


    <!-- add position -->
    <!-- scheduleAddModel  class para magalaw mo yung modal-->
    <div class="modal fade" id="scheduleAddModel" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Create New Schift</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <!-- saveSchedule id forms the only way bahala n kayo alam nyo na yan -->
                <form id="saveSchedule">
                    <div class="modal-body">
                        <div id="errorMessage" class="alert alert-warning d-none"></div>

                        <!-- inputs on form -->
                        <div class="mb-3">
                            <label for="">Time-In</label>
                            <input name="time_in" id="time_in_add" style="width:90%;float:left;" class="form-control" placeholder="HH:MM" />
                            <button type="button" class="btn btn-primary" onclick="showpickers('time_in_add',24)" style="width:40px;float:left;"><i class="fa fa-clock-o"></i>
                        </div>
                        <div class="timepicker"></div>

                        <div class="mb-3">
                            <label for="">Time-Out</label>
                            <input name="time_out" id="time_out_add" style="width:90%;float:left;" class="form-control" placeholder="HH:MM" />
                            <button type="button" class="btn btn-primary" onclick="showpickers('time_out_add',24)" style="width:40px;float:left;"><i class="fa fa-clock-o"></i>
                        </div>
                        <div class="timepicker"></div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- edit position -->
    <div class="modal fade" id="scheduleEditModel" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Edit Shift Info</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="updateSchedule">
                    <div class="modal-body">
                        <div id="errorMessageUpdate" class="alert alert-warning d-none"></div>
                        <!-- inputs on form -->
                        <input type="hidden" name="schedule_id" id="schedule_id">

                        <div class="mb-3">
                            <label for="">Time-In</label>
                            <input name="time_in" id="time_in" style="width:90%;float:left;" class="form-control" placeholder="HH:MM" />
                            <button type="button" class="btn btn-primary" onclick="showpickers('time_in',24)" style="width:40px;float:left;"><i class="fa fa-clock-o"></i>
                        </div>
                        <div class="timepicker"></div>

                        <div class="mb-3">
                            <label for="">Time-Out</label>
                            <input name="time_out" id="time_out" style="width:90%;float:left;" class="form-control" placeholder="HH:MM" />
                            <button type="button" class="btn btn-primary" onclick="showpickers('time_out',24)" style="width:40px;float:left;"><i class="fa fa-clock-o"></i>
                        </div>
                        <div class="timepicker"></div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Update Shift</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


    <!-- table display -->
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Shift List
                            <button type="button" class="btn btn-primary float-end" data-bs-toggle="modal" data-bs-target="#scheduleAddModel">
                            Create New Shift
                            </button>
                        </h4>
                    </div>
                    <div class="card-body">
                        <table id="myTable" class="table align-middle table-responsive-sm table-sm table-hover" >
                            <thead>
                                <tr>
                                    <th>Time In</th>
                                    <th>Time Out</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                require 'db_con.php';
                                $query="SELECT * FROM schedules";
                                $query_run = mysqli_query($con, $query);
                                
                                if(mysqli_num_rows($query_run)>0){
                                    foreach($query_run as $schedule){
                                        ?>
                                        <tr>
                                            <!-- id dimo pwede ibahin yan talaga nakalagay yan kasi ang hinatak ng id na yan sa mismong database -->
             <!-- pero yung iba pwede wag lang yang id basta depende sa gagawin mo kunware lalagyan mo yan gender dadag mo lang kunyare ayaw mong first name -->
                                            <td><?= $schedule['time_in']?></td>
                                            <td><?= $schedule['time_out']?></td>
                                            <td>
                                                <button type="button" value="<?=$schedule['id'];?>" class="editScheduleBtn btn btn-success">Edit</button>
                                                <button type="button" value="<?=$schedule['id'];?>" class="deleteScheduleBtn btn btn-danger">Delete</button>

                                            </td>
                                        </tr>
                                        <?php
                                    }
                                }
                                ?>
                                  
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!-- wag mo pla kalimutang mag sara ng mga kuwan basta gets muna yan para di ka mahirapan -->

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib\tpicker.js"></script>
    <script>
      
        //add schedule back end                            e-means event prevent page reload 
        $(document).on('submit','#saveSchedule', function (e) {
            e.preventDefault();
            // this mean submitting the form
            var formData = new FormData(this);
            formData.append("save_schedule",true);
            $.ajax({
                type: "POST",
                url: "schedule_process.php",
                data: formData,
                processData: false,
                contentType: false,
                success: function (response) {
                    var res = jQuery.parseJSON(response);
                    if(res.status == 422 ){
                        $('#errorMessage').removeClass('d-none');
                        $('#errorMessage').text(res.message);
                    }else if(res.status==200){
                        $('#errorMessage').addClass('d-none');
                        $('#scheduleAddModel').modal('hide');
                        $('#saveSchedule')[0].reset();
                        let myAlert = document.querySelector('.toast');
                        let bsAlert = new bootstrap.Toast(myAlert);
                        document.getElementById("textMessage").innerHTML = res.message;
                        bsAlert.show();
                        //!important $('#myTable').load(location.href + " #myTable"); nakita mo yung value ng myTable namay space sa una di pwedeng walang space yun pre
                        $('#myTable').load(location.href + " #myTable");
                    }
                }
            });
        });
        //edit schedule fetching our data in our input fields
        $(document).on('click', '.editScheduleBtn', function () {
            var schedule_id = $(this).val();
            $.ajax({
                type: "GET",
                url: "schedule_process.php?schedule_id=" + schedule_id,
                success: function (response) {
                    var res = jQuery.parseJSON(response);
                    if(res.status == 422 ){
                       alert(res.message);
                    }else if(res.status==200){
                        $('#schedule_id').val(res.data.id);
                        $('#time_in').val(res.data.time_in);
                        $('#time_out').val(res.data.time_out);
                        $('#scheduleEditModel').modal('show');

                    }
                }
            });
        });
        //to save the edited data
        $(document).on('submit','#updateSchedule', function (e) {
            e.preventDefault();
            // this mean submitting the form
            var formData = new FormData(this);
            formData.append("update_schedule",true);
            $.ajax({
                type: "POST",
                url: "schedule_process.php",
                data: formData,
                processData: false,
                contentType: false,
                success: function (response) {
                    var res = jQuery.parseJSON(response);
                    if(res.status == 422 ){
                        $('#errorMessageUpdate').removeClass('d-none');
                        $('#errorMessageUpdate').text(res.message);
                    }else if(res.status==200){
                        $('#errorMessageUpdate').addClass('d-none');
                        let myAlert = document.querySelector('.toast');
                        let bsAlert = new bootstrap.Toast(myAlert);
                        document.getElementById("textMessage").innerHTML = res.message;
                        bsAlert.show();
                        $('#scheduleEditModel').modal('hide');
                        $('#updateSchedule')[0].reset();
                        $('#myTable').load(location.href + " #myTable");

                    }
                }
            });
        });
        //delete
        $(document).on('click','.deleteScheduleBtn', function (e) {
            e.preventDefault();
            if(confirm('Are you sure you want to delete this info?')){
                var schedule_id = $(this).val();
                $.ajax({
                    type: "POST",
                    url: "schedule_process.php",
                    data: {
                        'delete_schedule': true,
                        'schedule_id': schedule_id
                    },
                    success: function (response) {
                        var res = jQuery.parseJSON(response);
                        if(res.status == 500){
                            alert(res.message);
                        }else{
                            let myAlert = document.querySelector('.toast');
                            let bsAlert = new bootstrap.Toast(myAlert);
                            document.getElementById("textMessage").innerHTML = res.message;
                            bsAlert.show();
                            $('#myTable').load(location.href + " #myTable");
                        }
                    }
                });
            }
        });
    </script>
</body>
</html>