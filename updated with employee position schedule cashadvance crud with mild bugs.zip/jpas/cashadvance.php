<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>JPAS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>
  <body>
<!-- tuss -->
<!-- toast - paramatawag yung toast      textMessage - para maapalitan yung laman -->
  <div class="toast-container position-fixed bottom-0 end-0 p-3">
  <div id="liveToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
    <div class="toast-header">
      <img src="..." class="rounded me-2" alt="...">
      <strong class="me-auto">JPAS</strong>
      <small>1 sec ago</small>
      <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
    <div class="toast-body" id="textMessage">

    </div>
  </div>
</div>


    <!-- add cashadvance -->
    <!-- cashadvanceAddModel  class para magalaw mo yung modal-->
    <div class="modal fade" id="cashadvanceAddModel" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Create New Position</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <!-- saveCashadvance id forms the only way bahala n kayo alam nyo na yan -->
                <form id="saveCashadvance">
                    <div class="modal-body">
                        <div id="errorMessage" class="alert alert-warning d-none"></div>
                        <!-- inputs on form -->
                        <div class="mb-3">
                            <label for="">Employee ID</label>
                            <input type="text" name="employee" class="form-control"/>
                        </div>
                        <div class="mb-3">
                            <label for="">Amount</label>
                            <input type="text" name="amount" class="form-control"/>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Save Position</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- edit cashadvance -->
    <div class="modal fade" id="cashadvanceEditModel" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Edit Position Info</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="updateCashadvance">
                    <div class="modal-body">
                        <div id="errorMessageUpdate" class="alert alert-warning d-none"></div>
                        <!-- inputs on form -->
                        <input type="hidden" name="cashadvance_id" id="cashadvance_id">
                        <div class="mb-3">
                            <label for="">Amount</label>
                            <input type="text" name="amount" id="amount" class="form-control"/>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Update Position</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


    <!-- table display -->
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Position List
                            <button type="button" class="btn btn-primary float-end" data-bs-toggle="modal" data-bs-target="#cashadvanceAddModel">
                            Create New Position
                            </button>
                        </h4>
                    </div>
                    <div class="card-body">
                        <table id="myTable" class="table align-middle table-responsive-sm table-sm table-hover" >
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Employee ID</th>
                                    <th>Name</th>
                                    <th>Amount</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                require 'db_con.php';
                                $query = "SELECT *, cashadvance.id AS caid, employees.employee_id AS empid FROM cashadvance LEFT JOIN employees ON employees.id=cashadvance.employee_id ORDER BY date_advance DESC";
                            
                                $query_run = mysqli_query($con, $query);
                                
                                if(mysqli_num_rows($query_run)>0){
                                    foreach($query_run as $cashadvance){
                                        ?>
                                        <tr>
                                            <!-- id dimo pwede ibahin yan talaga nakalagay yan kasi ang hinatak ng id na yan sa mismong database -->
             <!-- pero yung iba pwede wag lang yang id basta depende sa gagawin mo kunware lalagyan mo yan gender dadag mo lang kunyare ayaw mong first name -->
                                          
                                            <td><?php echo date('M d, Y', strtotime($cashadvance['date_advance']));?></td>
                                            <td><?php echo $cashadvance['empid'];?></td>
                                            <td><?php echo $cashadvance['firstname'].' '.$cashadvance['lastname']; ?></td>
                                            <td><?php echo number_format($cashadvance['amount'],2); ?></td>
                                            <td>
                                                <button type="button" value="<?=$cashadvance['caid'];?>" class="editCashadvanceBtn btn btn-success">Edit</button>
                                                <button type="button" value="<?=$cashadvance['caid'];?>" class="deleteCashadvanceBtn btn btn-danger">Delete</button>

                                            </td>
                                        </tr>
                                        <?php
                                    }
                                }
                                ?>
                                  
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!-- wag mo pla kalimutang mag sara ng mga kuwan basta gets muna yan para di ka mahirapan -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
    <script>
        //add cashadvance back end                            e-means event prevent page reload 
        $(document).on('submit','#saveCashadvance', function (e) {
            e.preventDefault();
            // this mean submitting the form
            var formData = new FormData(this);
            formData.append("save_cashadvance",true);
            $.ajax({
                type: "POST",
                url: "cashadvance_process.php",
                data: formData,
                processData: false,
                contentType: false,
                success: function (response) {
                    var res = jQuery.parseJSON(response);
                    if(res.status == 422 ){
                        $('#errorMessage').removeClass('d-none');
                        $('#errorMessage').text(res.message);
                    }else if(res.status==200){
                        $('#errorMessage').addClass('d-none');
                        $('#cashadvanceAddModel').modal('hide');
                        $('#saveCashadvance')[0].reset();
                        let myAlert = document.querySelector('.toast');
                        let bsAlert = new bootstrap.Toast(myAlert);
                        document.getElementById("textMessage").innerHTML = res.message;
                        bsAlert.show();
                        //!important $('#myTable').load(location.href + " #myTable"); nakita mo yung value ng myTable namay space sa una di pwedeng walang space yun pre
                        $('#myTable').load(location.href + " #myTable");
                    }
                }
            });
        });
        //edit cashadvance
        $(document).on('click', '.editCashadvanceBtn', function () {
            var cashadvance_id = $(this).val();
            $.ajax({
                type: "GET",
                url: "cashadvance_process.php?cashadvance_id=" + cashadvance_id,
                success: function (response) {
                    var res = jQuery.parseJSON(response);
                    if(res.status == 422 ){
                       alert(res.message);
                    }else if(res.status==200){
                        $('#cashadvance_id').val(res.data.id);
                        $('#amount').val(res.data.amount);
                      
                        $('#cashadvanceEditModel').modal('show');

                    }
                }
            });
        });
        //to save the edited data
        $(document).on('submit','#updateCashadvance', function (e) {
            e.preventDefault();
            // this mean submitting the form
            var formData = new FormData(this);
            formData.append("update_cashadvance",true);
            $.ajax({
                type: "POST",
                url: "cashadvance_process.php",
                data: formData,
                processData: false,
                contentType: false,
                success: function (response) {
                    var res = jQuery.parseJSON(response);
                    if(res.status == 422 ){
                        $('#errorMessageUpdate').removeClass('d-none');
                        $('#errorMessageUpdate').text(res.message);
                    }else if(res.status==200){
                        $('#errorMessageUpdate').addClass('d-none');
                        let myAlert = document.querySelector('.toast');
                        let bsAlert = new bootstrap.Toast(myAlert);
                        document.getElementById("textMessage").innerHTML = res.message;
                        bsAlert.show();
                        $('#cashadvanceEditModel').modal('hide');
                        $('#updateCashadvance')[0].reset();
                        $('#myTable').load(location.href + " #myTable");

                    }
                }
            });
        });
        //delete
        $(document).on('click','.deleteCashadvanceBtn', function (e) {
            e.preventDefault();
            if(confirm('Are you sure you want to delete this info?')){
                var cashadvance_id = $(this).val();
                $.ajax({
                    type: "POST",
                    url: "cashadvance_process.php",
                    data: {
                        'delete_cashadvance': true,
                        'cashadvance_id': cashadvance_id
                    },
                    success: function (response) {
                        var res = jQuery.parseJSON(response);
                        if(res.status == 500){
                            alert(res.message);
                        }else{
                            let myAlert = document.querySelector('.toast');
                            let bsAlert = new bootstrap.Toast(myAlert);
                            document.getElementById("textMessage").innerHTML = res.message;
                            bsAlert.show();
                            $('#myTable').load(location.href + " #myTable");
                        }
                    }
                });
            }
        });
    </script>
</body>
</html>