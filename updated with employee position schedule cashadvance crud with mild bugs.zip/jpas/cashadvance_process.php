<?php
require 'db_con.php';
//eto yung paraan para makapag delete ng cashadvance
// delete_cashadvance cashadvance_id positions yan pwede galawin yan
if(isset($_POST['delete_cashadvance'])){
    $cashadvance_id = mysqli_real_escape_string($con,$_POST['cashadvance_id']);
    $query = "DELETE FROM cashadvance WHERE id='$cashadvance_id'";
    $query_run = mysqli_query($con,$query);

    if($query_run){
        $res = [
            //statuses of input error
            'status' => 200,
            'message' => 'Position Info has been removed.'
        ];
        echo json_encode($res);
        return false;
    }else{
        $res = [
            //statuses of input error
            'status' => 500,
            'message' => 'Position Info not Deleted'
        ];
        echo json_encode($res);
        return false;
    }

}
//eto yung paraan para masave yung mga inedit na data mo sa input
// mga variable napwedeng palitan o dagdagan depende sa trip mo update_cashadvance cashadvance_id firstname, lastname, address, contact_info
if(isset($_POST['update_cashadvance'])){
    $cashadvance_id = mysqli_real_escape_string($con,$_POST['cashadvance_id']);
    //real escapre string function will protect you from sql function
    
    $amount = mysqli_real_escape_string($con,$_POST['amount']);
    
    if($amount==NULL){
        
        $res = [
            //statuses of input error
            'status' => 422,
            'message' => 'All fields are Mandatory'
        ];
        echo json_encode($res);
        return false;

        
    }
   //firstname lastname address contact_info cashadvance_id positions can change
    $query = "UPDATE cashadvance SET amount='$amount' WHERE id='$cashadvance_id'";
    $query_run = mysqli_query($con,$query);

    if($query_run){
        $res = [
            //statuses of input error
            'status' => 200,
            'message' => 'Position Info is Update Successfully'
        ];
        echo json_encode($res);
        return false;
    }else{
        $res = [
            //statuses of input error
            'status' => 500,
            'message' => 'Position did not Updated'
        ];
        echo json_encode($res);
        return false;
    }
}
//fetch cashadvance to text box of update can change
//cashadvance_id positions cashadvance
if(isset($_GET['cashadvance_id'])){
    $cashadvance_id = mysqli_real_escape_string($con,$_GET['cashadvance_id']);
    $query = "SELECT * FROM cashadvance WHERE id='$cashadvance_id'";
    $query_run = mysqli_query($con,$query);
    if(mysqli_num_rows($query_run)== 1){
        $cashadvance =mysqli_fetch_array($query_run);
        $res = [
            //statuses of input error
            'status' => 200,
            'message' => 'Position fetch successfully by id',
            'data' => $cashadvance
        ];
        echo json_encode($res);
        return false;
    }
    else{
        $res = [
            //statuses of input error
            'status' => 404,
            'message' => 'What?'
        ];
        echo json_encode($res);
        return false;
    }
}
//add cashadvance
////firstname lastname address contact_info 
if(isset($_POST['save_cashadvance'])){

    //real escapre string function will protect you from sql injectio function
    $employee = mysqli_real_escape_string($con,$_POST['employee']);
    $amount = mysqli_real_escape_string($con,$_POST['amount']);

    $empsql = "SELECT * FROM employees WHERE employee_id = '$employee'";
    $empquery = $con->query($empsql);
    if($empquery->num_rows<1){
        $_SESSION['error'] = 'Employee not found';
    }

    if($employee==NULL||$amount==NULL){
        $res = [
            //statuses of input error
            'status' => 422,
            'message' => 'All fields are Mandatory'
        ];
        echo json_encode($res);
        return false;
    }
    //firstname lastname address contact_info created_on
    $row = $empquery->fetch_assoc();
    $employee_id = $row['id'];
    $query = "INSERT INTO cashadvance (date_advance,employee_id,amount) VALUES (NOW(),'$employee_id','$amount')";
    $query_run = mysqli_query($con,$query);

    if($query_run){
        $res = [
            //statuses of input error
            'status' => 200,
            'message' => 'New Position is Recorded.'
        ];
        echo json_encode($res);
        return false;
    }else{
        $res = [
            //statuses of input error
            'status' => 500,
            'message' => 'Postion did not created :('
        ];
        echo json_encode($res);
        return false;
    }
}
?>