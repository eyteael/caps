<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>JPAS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
  <body>
<!-- tuss -->
<!-- toast - paramatawag yung toast      textMessage - para maapalitan yung laman -->
<div class="toast-container position-fixed bottom-0 end-0 p-3">
  <div id="liveToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
    <div class="toast-header">
      <img src="" class="rounded me-2" alt="">
      <strong class="me-auto">JPAS</strong>
      <small>1 sec ago</small>
      <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
    <div class="toast-body" id="textMessage">

    </div>
  </div>
</div>


    <!-- add employee -->
    <!-- employeeAddModel  class para magalaw mo yung modal-->

    
    <div class="modal fade" id="employeeAddModel" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Hire New Employee</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                 <!-- saveEmployee id forms the only way bahala n kayo alam nyo na yan  -->
                <form id="saveEmployee">
                    <div class="modal-body">
                        <div id="errorMessage" class="alert alert-warning d-none"></div>
                         <!-- inputs on form  -->
                        <div class="mb-3">
                            <label for="firstname">Firstname</label>
                            <input type="text" name="firstname" class="form-control"/>
                        </div>
                        <div class="mb-3">
                            <label for="lastname">Lastname</label>
                            <input type="text" name="lastname" class="form-control"/>
                        </div>
                        <div class="mb-3">
                            <label for="address">Address</label>
                            <input type="text" name="address" class="form-control"/>
                        </div>

                        <div class="mb-3">
                            <label for="birthdate">Birthdate</label>
                            <div class="input-group date" id="datepicker">
                                <input type="text" class="form-control" name="birthdate">
                                <span class="input-group-append">
                                    <span class="input-group-text bg-white d-block">
                                        <i class="fa fa-calendar"></i>
                                    </span>
                                </span>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="contact_info">Contact info</label>
                            <input type="text" name="contact_info" class="form-control"/>
                        </div>
                        <div class="mb-3">
                            <label for="edit_gender">Gender</label>
                            <select class="form-control" name="gender" id="edit_gender">
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="position">Position</label>
                            <select class="form-control" name="position">
                                <?php
                                include('db_con.php');
                                $sql = "SELECT * FROM position";
                                $query_run = mysqli_query($con, $sql); // Use $sql instead of $query
                                while ($prow = $query_run->fetch_assoc()) {
                                    echo "<option value='" . $prow['id'] . "'>" . $prow['description'] . "</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            
                            <label for="schedule">Schedules</label>
                            <select class="form-control" name="schedule">
                                <?php
                                $sql = "SELECT * FROM schedules";
                                $query_run = mysqli_query($con, $sql); // Use $sql instead of $query
                                while ($srow = $query_run->fetch_assoc()) {
                                    echo "<option value='".$srow['id']."'>".$srow['time_in'].' - '.$srow['time_out']."</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <dib class="mb-3">
                            <label for="photo">Upload</label>
                            <input type="file" name="photo">
                        </dib>
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Employ</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- edit employee -->
    <div class="modal fade" id="employeeEditModel" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Edit Employees Data</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="updateEmployee">
                    <div class="modal-body">
                        <div id="errorMessageUpdate" class="alert alert-warning d-none"></div>
                        <!-- inputs on form -->
                        <input type="hidden" name="employee_id" id="employee_id">
                        <div class="mb-3">
                            <label for="firstname">Firstname</label>
                            <input type="text" name="firstname" id="firstname" class="form-control"/>
                        </div>
                        <div class="mb-3">
                            <label for="lastname">Lastname</label>
                            <input type="text" name="lastname" id="lastname" class="form-control"/>
                        </div>
                        <div class="mb-3">
                            <label for="address">Address</label>
                            <input type="text" name="address" id="address" class="form-control"/>
                        </div>

                        <div class="mb-3">
                            <label for="birthdate">Birthdate</label>
                            <div class="input-group date" id="datepicker_edit">
                                <input type="text" class="form-control" name="birthdate" id="birthdate">
                                <span class="input-group-append">
                                    <span class="input-group-text bg-white d-block">
                                        <i class="fa fa-calendar"></i>
                                    </span>
                                </span>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="contact_info">Contact info</label>
                            <input type="text" name="contact_info" id="contact_info" class="form-control"/>
                        </div>

                        <div class="mb-3">
                            <label for="gender">Gender</label>
                            <select class="form-control" name="gender" id="gender">
                                <option selected id="gender_val"></option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="position">Position</label>
                            <select class="form-control" name="position" id="position">
                                <?php
                                include('db_con.php');
                                $sql = "SELECT * FROM position";
                                $query_run = mysqli_query($con, $sql); // Use $sql instead of $query
                                while ($prow = $query_run->fetch_assoc()) {
                                    echo "<option value='" . $prow['id'] . "'>" . $prow['description'] . "</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            
                            <label for="schedule">Schedules</label>
                            <select class="form-control" name="schedule" id="schedule">
                                <?php
                                $sql = "SELECT * FROM schedules";
                                $query_run = mysqli_query($con, $sql); // Use $sql instead of $query
                                while ($srow = $query_run->fetch_assoc()) {
                                    echo "<option value='".$srow['id']."'>".$srow['time_in'].' - '.$srow['time_out']."</option>";
                                }
                                ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="photo">Upload</label>
                            <input type="file" name="photo" id="photo">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Update Info</button>
                    </div>
                </form>
            </div>
        </div>
    </div>



    <!-- table display -->
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Employee List
                            <button type="button" class="btn btn-primary float-end" data-bs-toggle="modal" data-bs-target="#employeeAddModel">
                            Hire New Employee
                            </button>
                        </h4>
                    </div>
                    <div class="card-body">
                        <table id="myTable" class="table table-responsive-sm table-sm table-hover" >
                            <thead>
                                <tr>
                                    <th>Employee ID</th>
                                    <th>Photo</th>
                                    <th>Name</th>
                                    <th>Position</th>
                                    <th>Schedule</th>
                                    <th>Member Since</th>
                                    <th>Tools</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                require 'db_con.php';
                                $query = "SELECT *, employees.id AS id FROM employees LEFT JOIN position ON position.id=employees.position_id LEFT JOIN schedules ON schedules.id=employees.schedule_id";
                                $query_run = mysqli_query($con, $query);
                                
                                if(mysqli_num_rows($query_run)>0){
                                    foreach($query_run as $employee){
                                        ?>
                                        <tr>
                                            <!-- id dimo pwede ibahin yan talaga nakalagay yan kasi ang hinatak ng id na yan sa mismong database -->
             <!-- pero yung iba pwede wag lang yang id basta depende sa gagawin mo kunware lalagyan mo yan gender dadag mo lang kunyare ayaw mong first name -->
                                            <td><?= $employee['employee_id']?></td>
                                            <td><img src="<?php echo (!empty($employee['photo']))? './images/'.$employee['photo']:'./images/profile.jpg'; ?>" width="30px" height="30px"></td>
                                            <td><?php echo $employee['firstname'].' '.$employee['lastname']; ?></td>
                                            <td><?= $employee['address']?></td>
                                            <td><?php echo date('h:i A', strtotime($employee['time_in'])).' - '.date('h:i A', strtotime($employee['time_out'])); ?></td>
                                            <td><?= date('M d,Y', strtotime($employee['created_on']))  ?></td>
                                            <td>
                                                <button type="button" value="<?=$employee['id'];?>" class="editEmployeeBtn btn btn-success">Edit</button>
                                                <button type="button" value="<?=$employee['id'];?>" class="deleteEmployeeBtn btn btn-danger">Delete</button>

                                            </td>
                                        </tr>
                                        <?php
                                    }
                                }
                                ?>
                                  
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

       
<!-- wag mo pla kalimutang mag sara ng mga kuwan basta gets muna yan para di ka mahirapan -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
  
    <script>
             $('#datepicker').datepicker({
            autoclose: true,
            format: 'yyyy-mm-dd'
        })
        $('#datepicker_edit').datepicker({
            autoclose: true,
            format: 'yyyy-mm-dd'
        })

        $('.photo').click(function(e){
        e.preventDefault();
        var id = $(this).data('id');
        getRow(id);
    });
        
        //add employee back end                            e-means event prevent page reload 
        $(document).on('submit','#saveEmployee', function (e) {
            e.preventDefault();
            // this mean submitting the form
            var formData = new FormData(this);
            formData.append("save_employee",true);
            $.ajax({
                type: "POST",
                url: "employee_process.php",
                data: formData,
                processData: false,
                contentType: false,
                success: function (response) {
                    var res = jQuery.parseJSON(response);
                    if(res.status == 422 ){
                        $('#errorMessage').removeClass('d-none');
                        $('#errorMessage').text(res.message);
                    }else if(res.status==200){
                        $('#errorMessage').addClass('d-none');
                        $('#employeeAddModel').modal('hide');
                        $('#saveEmployee')[0].reset();
                        let myAlert = document.querySelector('.toast');
                        let bsAlert = new bootstrap.Toast(myAlert);
                        document.getElementById("textMessage").innerHTML = res.message;
                        bsAlert.show();
                        //!important $('#myTable').load(location.href + " #myTable"); nakita mo yung value ng myTable namay space sa una di pwedeng walang space yun pre
                        $('#myTable').load(location.href + " #myTable");
                    }
                }
            });
        });
        //edit employee
        $(document).on('click', '.editEmployeeBtn', function () {
            var employee_id = $(this).val();
            $.ajax({
                type: "GET",
                url: "employee_process.php?employee_id=" + employee_id,
                success: function (response) {
                    var res = jQuery.parseJSON(response);
                    if(res.status == 422 ){
                       alert(res.message);
                    }else if(res.status==200){
                        //nakabatay naman sa id ang mga putang inang to
                        $('#employee_id').val(res.data.id);
                        $('#firstname').val(res.data.firstname);
                        $('#lastname').val(res.data.lastname);
                        $('#address').val(res.data.address);
                        $('#birthdate').val(res.data.birthdate);
                        $('#contact_info').val(res.data.contact_info);
                        $('#gender').val(res.data.gender);
                        $('#position').val(res.data.position_id);
                        $('#schedule').val(res.data.schedule_id);
                        
                        $('#employeeEditModel').modal('show');

                    }
                }
            });
        });
        //to save the edited data
        $(document).on('submit','#updateEmployee', function (e) {
            e.preventDefault();
            // this mean submitting the form
            var formData = new FormData(this);
            formData.append("update_employee",true);
            $.ajax({
                type: "POST",
                url: "employee_process.php",
                data: formData,
                processData: false,
                contentType: false,
                success: function (response) {
                    var res = jQuery.parseJSON(response);
                    if(res.status == 422 ){
                        $('#errorMessageUpdate').removeClass('d-none');
                        $('#errorMessageUpdate').text(res.message);
                    }else if(res.status==200){
                        $('#errorMessageUpdate').addClass('d-none');
                        let myAlert = document.querySelector('.toast');
                        let bsAlert = new bootstrap.Toast(myAlert);
                        document.getElementById("textMessage").innerHTML = res.message;
                        bsAlert.show();
                        $('#employeeEditModel').modal('hide');
                        $('#updateEmployee')[0].reset();
                        $('#myTable').load(location.href + " #myTable");

                    }
                }
            });
        });
      
        //delete
        $(document).on('click','.deleteEmployeeBtn', function (e) {
            e.preventDefault();
            if(confirm('Are you sure you want to delete this info?')){
                var employee_id = $(this).val();
                $.ajax({
                    type: "POST",
                    url: "employee_process.php",
                    data: {
                        'delete_employee': true,
                        'employee_id': employee_id
                    },
                    success: function (response) {
                        var res = jQuery.parseJSON(response);
                        if(res.status == 500){
                            alert(res.message);
                        }else{
                            let myAlert = document.querySelector('.toast');
                            let bsAlert = new bootstrap.Toast(myAlert);
                            document.getElementById("textMessage").innerHTML = res.message;
                            bsAlert.show();
                            $('#myTable').load(location.href + " #myTable");
                        }
                    }
                });
            }
        });
    </script>
</body>
</html>